function showMessage() {
    const msg = document.getElementById('msg');
    msg.textContent = "Thanks for visiting my portfolio!";
}
